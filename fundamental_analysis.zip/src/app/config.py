# OPENAI_API_KEY='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'
# OPENAI_MODEL = "gpt-4o"

# src/app/config.py

import os
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o")


def get_llm_client():


    return OpenAI(api_key=OPENAI_API_KEY)