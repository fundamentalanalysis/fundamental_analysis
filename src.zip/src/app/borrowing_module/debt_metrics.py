# ==============================================================
# debt_metrics.py
# Core per-year metric calculations for Borrowings Module
# ==============================================================

from typing import Dict
from .debt_models import YearFinancialInput


def safe_div(a, b):
    return a / b if (b not in (0, None) and a is not None) else None


def compute_per_year_metrics(financials_5y, midd) -> Dict[int, dict]:
    """
    Input:  List[YearFinancialInput]
    Output:
        {
          2024: {
            "total_debt": ...,
            "st_debt_share": ...,
            "de_ratio": ...,
            "debt_ebitda": ...,
            "interest_coverage": ...,
            "floating_share": ...,
            "wacd": ...,
            "maturity_lt_1y_pct": ...,
            "maturity_1_3y_pct": ...,
            "maturity_gt_3y_pct": ...
          },
          2023: { ... },
          ...
        }
    """

    metrics = {}

    for f in financials_5y:
        total_debt = (f.short_term_debt or 0) + (f.long_term_debt or 0)

        metrics[f.year] = {
            "total_debt": total_debt,
            "st_debt_share": safe_div(f.short_term_debt, total_debt),
            "de_ratio": safe_div(total_debt, f.total_equity),
            "debt_ebitda": safe_div(total_debt, f.ebitda),
            "interest_coverage": safe_div(f.ebit, f.finance_cost),
            "floating_share": safe_div(midd['floating_rate_debt'], total_debt)
                if midd['floating_rate_debt'] else None,
            "wacd": midd['weighted_avg_interest_rate'],
            "maturity_lt_1y_pct": safe_div(midd['total_debt_maturing_lt_1y'], total_debt)
                if midd['total_debt_maturing_lt_1y'] else None,
            "maturity_1_3y_pct": safe_div(midd['total_debt_maturing_1_3y'], total_debt)
                if midd['total_debt_maturing_1_3y'] else None,
            "maturity_gt_3y_pct": safe_div(midd['total_debt_maturing_gt_3y'], total_debt)
                if midd['total_debt_maturing_gt_3y'] else None,
        }
        

    return metrics

