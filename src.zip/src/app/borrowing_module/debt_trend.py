# src/app/borrowing_module/debt_trend.py

def compute_cagr(start, end, years=4):
    if not start or not end or start == 0:
        return None
    return (end / start) ** (1 / years) - 1


def compute_trend_metrics(financials, yearly):
    years = sorted(yearly.keys())
    first = years[0]
    last = years[-1]

    debt_start = yearly[first]["total_debt"]
    debt_end = yearly[last]["total_debt"]

    ebitda_start = next(f.ebitda for f in financials if f.year == first)
    ebitda_end = next(f.ebitda for f in financials if f.year == last)

    debt_cagr = compute_cagr(debt_start, debt_end)
    ebitda_cagr = compute_cagr(ebitda_start, ebitda_end)

    return {
        "debt_cagr": debt_cagr,
        "ebitda_cagr": ebitda_cagr,
        "debt_growth_vs_ebitda": (
            debt_cagr - ebitda_cagr if debt_cagr and ebitda_cagr else None
        )
    }
