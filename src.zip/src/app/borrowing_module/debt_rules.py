# # app/rule_engine.py

# from .models import RuleResult
# from collections import Counter


# def make(rule_id, name, flag, value, threshold, reason):
#     return RuleResult(
#         rule_id=rule_id,
#         rule_name=name,
#         flag=flag,
#         value=value,
#         threshold=threshold,
#         reason=reason
#     )


# def apply_rules(financials, metrics, trends):

#     results = []
#     last = sorted(metrics.keys())[-1]
#     m = metrics[last]

#     # -------------------------------------------------
#     # B1 – Debt to Equity
#     # -------------------------------------------------
#     if m["de_ratio"] is not None:
#         if m["de_ratio"] > 1:
#             results.append(make("B1", "Debt-to-Equity", "RED", m["de_ratio"], ">1",
#                                 "Highly leveraged"))
#         elif m["de_ratio"] > 0.5:
#             results.append(make("B1", "Debt-to-Equity", "YELLOW", m["de_ratio"], "0.5–1",
#                                 "Moderate leverage"))
#         else:
#             results.append(make("B1", "Debt-to-Equity", "GREEN", m["de_ratio"], "<=0.5",
#                                 "Healthy leverage"))

#     # -------------------------------------------------
#     # B2 – Debt-to-EBITDA
#     # -------------------------------------------------
#     if m["debt_ebitda"] is not None:
#         if m["debt_ebitda"] > 4:
#             results.append(make("B2", "Debt-to-EBITDA", "RED", m["debt_ebitda"], ">4",
#                                 "Very high leverage"))
#         elif m["debt_ebitda"] > 2:
#             results.append(make("B2", "Debt-to-EBITDA", "YELLOW", m["debt_ebitda"], "2–4",
#                                 "Moderate stress"))
#         else:
#             results.append(make("B2", "Debt-to-EBITDA", "GREEN", m["debt_ebitda"], "<=2",
#                                 "Healthy"))

#     # -------------------------------------------------
#     # C1 – Interest Coverage
#     # -------------------------------------------------
#     if m["interest_coverage"] is not None:
#         if m["interest_coverage"] < 1.5:
#             results.append(make("C1", "Interest Coverage", "RED",
#                                 m["interest_coverage"], "<1.5",
#                                 "Weak ability to service interest"))
#         elif m["interest_coverage"] < 3:
#             results.append(make("C1", "Interest Coverage", "YELLOW",
#                                 m["interest_coverage"], "1.5–3",
#                                 "Moderately stressed"))
#         else:
#             results.append(make("C1", "Interest Coverage", "GREEN",
#                                 m["interest_coverage"], ">=3",
#                                 "Comfortable servicing ability"))

#     return results

# debt_rules.py

# ==============================================================
# debt_rules.py
# Deterministic rule engine for Borrowings Module
# ==============================================================


# src/app/borrowing_module/debt_rules.py

from src.app.borrowing_module.debt_models import RuleResult

def make(flag, id, name, value, threshold, reason):
    return RuleResult(
        rule_id=id,
        rule_name=name,
        flag=flag,
        value=value,
        threshold=threshold,
        reason=reason
    )


def apply_rules(financials, metrics, trends):

    results = []
    last_year = max(metrics.keys())
    m = metrics[last_year]

    # B1 - D/E Ratio
    if m["de_ratio"] is not None:
        if m["de_ratio"] > 1:
            results.append(make("RED", "B1", "Debt-to-Equity", m["de_ratio"], ">1", "Highly leveraged"))
        elif m["de_ratio"] > 0.5:
            results.append(make("YELLOW", "B1", "Debt-to-Equity", m["de_ratio"], "0.5–1", "Moderate leverage"))
        else:
            results.append(make("GREEN", "B1", "Debt-to-Equity", m["de_ratio"], "<=0.5", "Healthy leverage"))

    # B2 - Debt/EBITDA
    if m["debt_ebitda"] is not None:
        if m["debt_ebitda"] > 4:
            results.append(make("RED", "B2", "Debt-to-EBITDA", m["debt_ebitda"], ">4", "Very high leverage"))
        elif m["debt_ebitda"] > 2:
            results.append(make("YELLOW", "B2", "Debt-to-EBITDA", m["debt_ebitda"], "2–4", "Moderate leverage"))
        else:
            results.append(make("GREEN", "B2", "Debt-to-EBITDA", m["debt_ebitda"], "<=2", "Healthy"))

    # C1 – Interest Coverage
    if m["interest_coverage"] is not None:
        if m["interest_coverage"] < 1.5:
            results.append(make("RED", "C1", "Interest Coverage", m["interest_coverage"], "<1.5", "Cannot service interest"))
        elif m["interest_coverage"] < 3:
            results.append(make("YELLOW", "C1", "Interest Coverage", m["interest_coverage"], "1.5–3", "Moderately stressed"))
        else:
            results.append(make("GREEN", "C1", "Interest Coverage", m["interest_coverage"], ">=3", "Comfortable"))

    return results
